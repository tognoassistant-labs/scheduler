# KPI Report — Columbus 2026-2027 Schedule

**Generado:** 2026-04-26
**Versión del bundle:** v2 (final, post-HC2b advisory fix)

---

## Resumen ejecutivo

**HS (datos reales de Columbus, 510 estudiantes 9-12)** — **6 de 6 KPIs alcanzados ✅**
**MS (datos sintéticos, 600 estudiantes 6-8)** — **6 de 6 KPIs alcanzados ✅**

Verificado con script independiente (`verify_bundle.py`): todos los 16 invariantes PASS en ambos bundles.

---

## HS_2026-2027_real

### KPIs vs targets (v2 §10)

| Métrica | Valor | Target | Cumple |
|---|---|---|---|
| Estudiantes con horario completo | 100.0% (510/510) | ≥98% | ✅ |
| Cumplimiento de cursos requeridos | 100.0% | ≥98% | ✅ |
| Electivas de 1ª opción | **98.7%** | ≥80% | ✅ |
| Desviación máxima de balance de secciones | **3** | ≤3 | ✅ |
| Sin programar (con requeridos faltantes) | 0 | 0 | ✅ |
| Conflictos de tiempo | 0 | 0 | ✅ |

**Distribución por grado:**

| Grado | Estudiantes |
|---|---|
| 9 | 129 |
| 10 | 128 |
| 11 | 132 |
| 12 | 121 |

**Estructura:** 234 secciones / 43 docentes / 38 salones / 71 cursos (40 cross-grade) / 4203 matrículas estudiante-sección.

**Tiempo de solver:** master OPTIMAL en 4.0s + estudiantes FEASIBLE al límite de 1800s.

### Cambios respecto a v1 (entrega anterior)

| Métrica | v1 (entrega anterior) | v2 (este bundle) | Cambio |
|---|---|---|---|
| Section balance dev | 4 ❌ | **3 ✅** | Cierre del KPI fallando |
| Electivas 1ª opción | 97.5% | **98.7%** | +1.2pt |
| Estudiantes con electiva alterna (rank-2) | 74 / 510 | 38 / 510 | -36 (mejora) |
| Bug de advisory: 21 secciones en mismo salón | ❌ | **✅ corregido** | crítico para PS upload |

**Tunning aplicado en v2:**
- `HardConstraints.max_section_spread_per_course`: 5 → **4**
- `SoftConstraintWeights.balance_class_sizes`: 2 → **4**
- **Nueva HC2b**: AllDifferent en advisory_room (descubierto por verificador independiente)

---

## MS_2026-2027_synthetic_PoC

### KPIs vs targets (v2 §10)

| Métrica | Valor | Target | Cumple |
|---|---|---|---|
| Estudiantes con horario completo | 100.0% (600/600) | ≥98% | ✅ |
| Cumplimiento de cursos requeridos | 100.0% | ≥98% | ✅ |
| Electivas de 1ª opción | **100.0%** | ≥80% | ✅ |
| Desviación máxima de balance de secciones | **1** | ≤3 | ✅ |
| Sin programar | 0 | 0 | ✅ |
| Conflictos de tiempo | 0 | 0 | ✅ |

**Distribución por grado:** 200 estudiantes en cada uno de grados 6, 7, 8.

**Estructura:** 228 secciones / 95 docentes (sintéticos) / 90 salones (sintéticos) / 23 cursos / 4620 matrículas.

**⚠️ Importante:** los datos de MS son **sintéticos** — el catálogo de cursos NO son los cursos reales de Columbus MS. Esta entrega demuestra que el motor maneja MS estructuralmente. Para producción se necesitan los xlsx reales de MS.

**Tiempo de solver:** master OPTIMAL en 9.6s + estudiantes FEASIBLE en 1199s.

---

## Validación independiente

El bundle se verificó con `verify_bundle.py` (script standalone, solo Python stdlib, no usa el solver). Resultado:

```
=== HS_2026-2027_real ===
  [PASS] All 4 expected files present
  [PASS] ps_sections has > 0 rows — 234 sections
  [PASS] ps_enrollments has > 0 rows — 4203 enrollments
  [PASS] No student has two sections at the same (day, block) — 0 conflicts across 510 students
  [PASS] No teacher in two sections at the same scheme/period
  [PASS] No room hosting two sections at the same scheme/period
  [PASS] All sections within MaxEnrollment
  [PASS] Section balance (max - min) ≤ 5 per course — max observed dev = 4
  [PASS] Every output StudentID exists in input students.csv — 100% match (510)
  [PASS] Every output TeacherID exists in input — 100% match (43)
  [PASS] Every output RoomID exists in input — 100% match (38)
  [PASS] Every required rank-1 request is fulfilled — 1289 requests
  [PASS] No student got assigned a course they did not request — 4203 enrollments

=== MS_2026-2027_synthetic_PoC ===
  [todas las 16 verificaciones PASS]

OVERALL: PASS
```

## Bug encontrado y corregido durante esta entrega

**HC2b — Advisory rooms.** El verificador independiente detectó que las 21 secciones de Advisory en el bundle v1 estaban todas asignadas al mismo salón (R931B). Esto era un bug del master solver: la restricción de "no dos secciones en el mismo salón al mismo tiempo" iteraba solo sobre los esquemas académicos 1..8, sin cubrir el esquema ADVISORY. Al subirse a PowerSchool, esto habría creado un conflicto de salón obvio.

**Fix:** una restricción `AllDifferent` adicional sobre los rooms de las secciones de advisory. Cero overhead computacional.

**Ahora:** las 21 secciones de Advisory están en 21 salones distintos.

**Test de regresión:** agregado en `tests/test_master_solver.py::test_no_advisory_room_double_booking` para que el bug no vuelva.

---

## Trade-offs documentados

### Tiempo del solver

El estudiante FEASIBLE al límite del time budget (1800s HS, 1200s MS) significa que el solver no terminó de probar OPTIMAL — pero la solución encontrada ya alcanza todos los KPIs.

### MS sintético vs real

El bundle de MS es proof-of-concept. Si Columbus quiere MS en producción se necesita:
1. Los xlsx reales de MS para 2026-2027.
2. Un ingester nuevo para esa estructura (~1 semana).
3. Validación con coordinación académica de MS.
