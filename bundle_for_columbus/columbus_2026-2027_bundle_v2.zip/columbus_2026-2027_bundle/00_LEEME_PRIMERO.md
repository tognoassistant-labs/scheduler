# Columbus — Bundle de horarios 2026-2027

**Generado:** 2026-04-26
**Versión:** v2 (rebalanceada, con MS sintético y preguntas pendientes)

> _English version: [00_README_FIRST_en.md](00_README_FIRST_en.md)._

---

## Estructura del paquete

```
columbus_2026-2027_bundle/
├── 00_LEEME_PRIMERO.md                 ← este archivo
├── 00_README_FIRST_en.md               ← versión en inglés
├── 01_PREGUNTAS_PARA_COLUMBUS.md       ← bloqueadores y verificaciones pendientes ⚠️
├── 01_QUESTIONS_FOR_COLUMBUS_en.md     ← versión en inglés
├── 02_KPI_REPORT.md                    ← resumen de qué KPIs alcanzamos
│
├── HS_2026-2027_real/                  ← datos reales de Columbus (510 estudiantes)
│   ├── horario_estudiantes/
│   │   └── student_schedules_friendly.csv
│   ├── powerschool_upload/
│   │   ├── ps_sections.csv
│   │   ├── ps_enrollments.csv
│   │   ├── ps_master_schedule.csv
│   │   └── ps_field_mapping.md
│   └── lms_upload/
│       └── (7 CSVs OneRoster v1.1)
│
└── MS_2026-2027_synthetic_PoC/         ← prueba de concepto (datos sintéticos)
    ├── horario_estudiantes/
    │   └── student_schedules_friendly.csv
    ├── powerschool_upload/
    │   └── (3 CSVs PS)
    └── lms_upload/
        └── (7 CSVs OneRoster)
```

## Orden de lectura recomendado

1. **Este archivo** (5 min) — entender qué es cada cosa.
2. **`01_PREGUNTAS_PARA_COLUMBUS.md`** (15 min) — **estas preguntas bloquean activamente la importación a producción**. Responderlas es el siguiente paso crítico.
3. **`02_KPI_REPORT.md`** (5 min) — resumen visual de los resultados del solver.
4. **`HS_2026-2027_real/horario_estudiantes/student_schedules_friendly.csv`** — abrir en Excel para ver cualquier horario individual.

## Lo que está en este bundle

### HS (datos reales de Columbus)

- **510 estudiantes** ubicados en grados 9-12 (129 / 128 / 132 / 121)
- **234 secciones** dictadas por 43 docentes en 38 salones
- Datos extraídos de `rfi_1._STUDENTS_PER_COURSE_2026-2027.xlsx` y `rfi_HS_Schedule_25-26.xlsx`
- Listo para subir a PowerSchool y a cualquier LMS compatible con OneRoster

### MS (prueba de concepto sintético)

- **600 estudiantes sintéticos** en grados 6-8 (200 cada uno)
- Catálogo de cursos sintético — **no son los cursos reales de Columbus MS**
- Mismo motor, misma rotación A-E (per v2 §4.2)
- **Propósito:** demostrar que el motor maneja MS estructuralmente. Para producción de MS necesitamos los xlsx reales (ver pregunta B3 en `01_PREGUNTAS_PARA_COLUMBUS.md`).

## Qué hacer ahora (orden recomendado)

### Paso 1 — Revisar las preguntas que bloquean (esta semana)
Abrir `01_PREGUNTAS_PARA_COLUMBUS.md`. Las preguntas de la sección **A** bloquean la importación a PowerSchool. Las de la sección **B** bloquean el alcance del proyecto. Cada respuesta acerca el go-live.

### Paso 2 — Revisar el horario en Excel (esta semana)
Abrir `HS_2026-2027_real/horario_estudiantes/student_schedules_friendly.csv` en Excel. Filtrar por `StudentID` para ver el horario completo de cualquier estudiante. Compartir con 1-2 coordinadores académicos para validación humana.

### Paso 3 — Probar en sandbox de PowerSchool (la próxima semana)
**Antes de importar a producción**, hacer un dry-run en sandbox con `HS_2026-2027_real/powerschool_upload/ps_sections.csv`. Esto valida que el formato de campos coincida con su instancia de PS. Si no hay sandbox, ver pregunta A8.

### Paso 4 — Importar a producción (después del sandbox)
Una vez validado el formato y confirmadas las preguntas A1-A7, los CSVs están listos para producción. La recomendación es importar en este orden:
1. `ps_sections.csv` → módulo Sections de PS
2. `ps_enrollments.csv` → módulo CC (course-section enrollments) de PS

`ps_master_schedule.csv` no se importa; es para revisión por coordinación.

## Cambios respecto a la entrega anterior (v1 → v2)

- ✨ **Balance de secciones mejorado:** ver `02_KPI_REPORT.md` para el detalle. v1 tenía dev=4; v2 prueba con `max_section_spread_per_course=4` y peso de balance aumentado.
- ✨ **MS sintético incluido:** demostración de que el motor maneja MS, no producción.
- ✨ **Estructura de carpetas numerada** para facilitar navegación.
- ✨ **Documento de preguntas bilingüe** explicando todos los bloqueadores conocidos.

## Soporte

Para preguntas técnicas: [punto de contacto técnico — pendiente, ver F1 en preguntas]

Para preguntas operativas o de alcance: [pendiente]
