# Columbus — Schedule Bundle 2026-2027

**Generated:** 2026-04-26
**Version:** v2 (rebalanced, with synthetic MS and pending questions)

> _Versión en español: [00_LEEME_PRIMERO.md](00_LEEME_PRIMERO.md)._

---

## Bundle structure

```
columbus_2026-2027_bundle/
├── 00_LEEME_PRIMERO.md                 ← Spanish version (primary)
├── 00_README_FIRST_en.md               ← this file
├── 01_PREGUNTAS_PARA_COLUMBUS.md       ← blockers and pending verifications ⚠️
├── 01_QUESTIONS_FOR_COLUMBUS_en.md     ← English version
├── 02_KPI_REPORT.md                    ← summary of KPIs achieved
│
├── HS_2026-2027_real/                  ← real Columbus data (510 students)
│   ├── horario_estudiantes/
│   │   └── student_schedules_friendly.csv
│   ├── powerschool_upload/
│   │   ├── ps_sections.csv
│   │   ├── ps_enrollments.csv
│   │   ├── ps_master_schedule.csv
│   │   └── ps_field_mapping.md
│   └── lms_upload/
│       └── (7 OneRoster v1.1 CSVs)
│
└── MS_2026-2027_synthetic_PoC/         ← proof of concept (synthetic data)
    ├── horario_estudiantes/
    │   └── student_schedules_friendly.csv
    ├── powerschool_upload/
    │   └── (3 PS CSVs)
    └── lms_upload/
        └── (7 OneRoster CSVs)
```

## Recommended reading order

1. **This file** (5 min) — understand what each thing is.
2. **`01_QUESTIONS_FOR_COLUMBUS_en.md`** (15 min) — **these questions actively block production import**. Answering them is the next critical step.
3. **`02_KPI_REPORT.md`** (5 min) — visual summary of solver results.
4. **`HS_2026-2027_real/horario_estudiantes/student_schedules_friendly.csv`** — open in Excel to view any individual schedule.

## What's in this bundle

### HS (real Columbus data)

- **510 students** placed across grades 9-12 (129 / 128 / 132 / 121)
- **234 sections** taught by 43 teachers in 38 rooms
- Data extracted from `rfi_1._STUDENTS_PER_COURSE_2026-2027.xlsx` and `rfi_HS_Schedule_25-26.xlsx`
- Ready to upload to PowerSchool and any OneRoster-compatible LMS

### MS (synthetic proof of concept)

- **600 synthetic students** in grades 6-8 (200 each)
- Synthetic course catalog — **NOT Columbus MS's real courses**
- Same engine, same A-E rotation (per v2 §4.2)
- **Purpose:** demonstrate the engine handles MS structurally. For production MS we need the real xlsx files (see question B3 in `01_QUESTIONS_FOR_COLUMBUS_en.md`).

## What to do now (recommended order)

### Step 1 — Review the blocking questions (this week)
Open `01_QUESTIONS_FOR_COLUMBUS_en.md`. Section **A** questions block PowerSchool import. Section **B** questions block project scope. Each answer brings go-live closer.

### Step 2 — Review the schedule in Excel (this week)
Open `HS_2026-2027_real/horario_estudiantes/student_schedules_friendly.csv` in Excel. Filter by `StudentID` to view any student's full schedule. Share with 1-2 academic coordinators for human validation.

### Step 3 — Test in PowerSchool sandbox (next week)
**Before importing to production**, do a dry-run in sandbox with `HS_2026-2027_real/powerschool_upload/ps_sections.csv`. This validates that field formats match your PS instance. If no sandbox exists, see question A8.

### Step 4 — Import to production (after sandbox)
Once format is validated and questions A1-A7 are answered, the CSVs are ready for production. Recommended import order:
1. `ps_sections.csv` → PS Sections module
2. `ps_enrollments.csv` → PS CC (course-section enrollments) module

`ps_master_schedule.csv` is not imported; it's for academic-coordination review.

## Changes since previous delivery (v1 → v2)

- ✨ **Improved section balance:** see `02_KPI_REPORT.md` for detail. v1 had dev=4; v2 attempts `max_section_spread_per_course=4` and increased balance weight.
- ✨ **Synthetic MS included:** demonstration that the engine handles MS, not production.
- ✨ **Numbered folder structure** for easier navigation.
- ✨ **Bilingual questions document** explaining all known blockers.

## Support

For technical questions: [technical point of contact — pending, see F1 in questions]

For operational or scope questions: [pending]
