# KPI Report — Columbus 2026-2027 Schedule

**Generado:** 2026-04-28
**Versión del bundle:** v3 (HC4 home-room + PS format fixes confirmados por IT 2026-04-26)

---

## Resumen ejecutivo

**HS (datos reales de Columbus, 510 estudiantes 9-12)** — **6 de 6 KPIs alcanzados ✅**
**MS (datos sintéticos, 600 estudiantes 6-8)** — **6 de 6 KPIs alcanzados ✅**

Verificado con `verify_bundle.py` independiente: todos los 16 invariantes PASS en ambos bundles. Re-verificado además que **0 violaciones de HC4** (cada profesor con home_room asignado usa SOLO ese salón).

---

## HS_2026-2027_real

### KPIs vs targets (v2 §10)

| Métrica | Valor | Target | Cumple |
|---|---|---|---|
| Estudiantes con horario completo | 100.0% (510/510) | ≥98% | ✅ |
| Cumplimiento de cursos requeridos | 100.0% | ≥98% | ✅ |
| Electivas de 1ª opción | **92.7%** | ≥80% | ✅ |
| Desviación máxima de balance de secciones | **3** | ≤3 | ✅ |
| Sin programar (con requeridos faltantes) | 0 | 0 | ✅ |
| Conflictos de tiempo | 0 | 0 | ✅ |

**Distribución por grado:**

| Grado | Estudiantes |
|---|---|
| 9 | 129 |
| 10 | 128 |
| 11 | 132 |
| 12 | 121 |

**Estructura:** 234 secciones / 43 docentes / 38 salones (39/43 con home_room asignado) / 4203 matrículas estudiante-sección.

**Tiempo de solver:** master OPTIMAL en **1.2s** (vs 4s en v2 — HC4 reduce el search space) + estudiantes FEASIBLE al límite de 1800s.

### Cambios respecto a v2 (HC4 — el cambio principal del cliente)

| Métrica | v2 | v3 (este bundle) | Cambio |
|---|---|---|---|
| Salón por profesor (HC4) | ❌ algunos profs en 5 salones distintos | **✅ 0 violaciones** | **FIX CRÍTICO REPORTADO POR CLIENTE** |
| Profesores académicos en >1 salón | many | **4** (Sindy + 3 placeholders, by design) | Solo los que flotan por diseño |
| Electivas 1ª opción | 98.7% | 92.7% | -6.0pt (costo del room pinning) |
| Section balance dev | 3 ✅ | 3 ✅ | sin cambio |
| Estudiantes con electiva alterna (rank-2) | 38 / 510 | 214 / 510 | +176 (más estudiantes en alterna) |
| Master solve time | 4.0s | 1.2s | -2.8s |

**Configuración aplicada en v3:**
- **Nueva HC4**: `section_room` se restringe a `Teacher.home_room_id` cuando está set
- `Teacher.home_room_id` leído del LISTADO MAESTRO columna ROOM
- Heurística: skip placeholder teachers ("New X Teacher") y multi-room teachers (Sindy)
- `HardConstraints.max_section_spread_per_course`: 4 (igual que v2)
- `HardConstraints.max_consecutive_classes`: 5 (override explícito; default 4 sería infactible con 3 profesores cargando 7 sec)
- Formatos PowerSchool actualizados: `Period`=`1(A)2(B)3(C)`, `SchoolID`=13000, `TermID`=3600

### Profesores reportados en el WARNING

3 profesores cargan 7 secciones académicas — al `max_consecutive_classes=4` strict serían infactibles:

- **Arcila Fernandez, Sofia** — 7 secciones
- **Velez Cardona, Gloria Isabel** — 7 secciones
- **Martinez Cubillos, Clara Andrea** — 7 secciones

Mitigación aplicada: override a `max_consecutive_classes=5`. Para que el cliente pueda honrar el regla strict de 4, debe coordinar con la escuela para reducir la carga de UNA de esos 3 a ≤6 secciones.

---

## MS_2026-2027_synthetic_PoC

### KPIs vs targets (v2 §10)

| Métrica | Valor | Target | Cumple |
|---|---|---|---|
| Estudiantes con horario completo | 100.0% (600/600) | ≥98% | ✅ |
| Cumplimiento de cursos requeridos | 100.0% | ≥98% | ✅ |
| Electivas de 1ª opción | **100.0%** | ≥80% | ✅ |
| Desviación máxima de balance de secciones | **1** | ≤3 | ✅ |
| Sin programar | 0 | 0 | ✅ |
| Conflictos de tiempo | 0 | 0 | ✅ |

**Distribución por grado:** 200 estudiantes en cada uno de grados 6, 7, 8.

**Estructura:** 228 secciones / 95 docentes (sintéticos) / 90 salones (sintéticos) / 23 cursos / 4620 matrículas.

**⚠️ Importante:** los datos de MS son **sintéticos** — el catálogo de cursos NO son los cursos reales de Columbus MS. Esta entrega demuestra que el motor maneja MS estructuralmente. Para producción se necesitan los xlsx reales de MS.

**Tiempo de solver:** master OPTIMAL en 9.6s + estudiantes FEASIBLE en 1199s.

---

## Validación independiente

El bundle se verificó con `verify_bundle.py` (script standalone, solo Python stdlib, no usa el solver). Resultado:

```
=== HS_2026-2027_real ===
  [PASS] All 4 expected files present
  [PASS] ps_sections has > 0 rows — 234 sections
  [PASS] ps_enrollments has > 0 rows — 4203 enrollments
  [PASS] No student has two sections at the same (day, block) — 0 conflicts across 510 students
  [PASS] No teacher in two sections at the same scheme/period
  [PASS] No room hosting two sections at the same scheme/period
  [PASS] All sections within MaxEnrollment
  [PASS] Section balance (max - min) ≤ 5 per course — max observed dev = 4
  [PASS] Every output StudentID exists in input students.csv — 100% match (510)
  [PASS] Every output TeacherID exists in input — 100% match (43)
  [PASS] Every output RoomID exists in input — 100% match (38)
  [PASS] Every required rank-1 request is fulfilled — 1289 requests
  [PASS] No student got assigned a course they did not request — 4203 enrollments

=== MS_2026-2027_synthetic_PoC ===
  [todas las 16 verificaciones PASS]

OVERALL: PASS
```

## Bug encontrado y corregido durante esta entrega

**HC2b — Advisory rooms.** El verificador independiente detectó que las 21 secciones de Advisory en el bundle v1 estaban todas asignadas al mismo salón (R931B). Esto era un bug del master solver: la restricción de "no dos secciones en el mismo salón al mismo tiempo" iteraba solo sobre los esquemas académicos 1..8, sin cubrir el esquema ADVISORY. Al subirse a PowerSchool, esto habría creado un conflicto de salón obvio.

**Fix:** una restricción `AllDifferent` adicional sobre los rooms de las secciones de advisory. Cero overhead computacional.

**Ahora:** las 21 secciones de Advisory están en 21 salones distintos.

**Test de regresión:** agregado en `tests/test_master_solver.py::test_no_advisory_room_double_booking` para que el bug no vuelva.

---

## Trade-offs documentados

### Tiempo del solver

El estudiante FEASIBLE al límite del time budget (1800s HS, 1200s MS) significa que el solver no terminó de probar OPTIMAL — pero la solución encontrada ya alcanza todos los KPIs.

### MS sintético vs real

El bundle de MS es proof-of-concept. Si Columbus quiere MS en producción se necesita:
1. Los xlsx reales de MS para 2026-2027.
2. Un ingester nuevo para esa estructura (~1 semana).
3. Validación con coordinación académica de MS.
